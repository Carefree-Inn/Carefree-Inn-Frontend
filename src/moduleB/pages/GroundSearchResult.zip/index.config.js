export default definePageConfig({
  navigationBarTitleText: '广场搜索'
})
